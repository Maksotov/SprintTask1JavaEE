package bitlab.techorda.kz.db;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DBManager {
    private static final List<Task> tasks = new ArrayList<>();
    private static long id = 1;
    static {
        tasks.add(
                new Task(
                    id++,
                    "Создать Веб приложение на Java EE",
                    "Нужно будет создать собственное приложение на Java EE " +
                            "для себя.Для начало я установлю себе на комп Composer." +
                            "Затем тупо загружу Java EE и запущу",
                    "01.05.2023"

                )
        );

        tasks.add(
                new Task(
                        id++,
                        "Убраться дома и закупить продукты",
                        "Когда я проснусь сразу же надо начать убираться," +
                                "после обеда пойти в магазит и закупиться",
                        "02.05.2023"

                )
        );

        tasks.add(
                new Task(
                        id++,
                        "Выполнить все домашние задания",
                        "После урока остаться и делать уроки",
                        "03.05.2023"

                )
        );

        tasks.add(
                new Task(
                        id++,
                        "Записаться на качку",
                        "Надо подкачаться",
                        "03.05.2023"

                )
        );

        tasks.add(
                new Task(
                        id++,
                        "Учить Италянский",
                        "Надо начать учить италянский",
                        "04.05.2023"

                )
        );
    }


    public static List<Task> getAllTasks() {
        return tasks;
    }

    public static void addTask(Task task) {
        task.setId(id++);
        tasks.add(task);
    }

    public static Task getTask(Long id) {
        return tasks.stream()
                .filter(task -> task.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public static void deleteTask(Long id) {
        for(int i = 0; i < tasks.size(); i++) {
            if(Objects.equals(tasks.get(i).getId(), id)) {
                tasks.remove(i);
            }
        }
    }

    public static void updateTask(Task task) {
        for(int i = 0; i < tasks.size(); i++) {
            if(Objects.equals(tasks.get(i).getId(), task.getId())) {
                tasks.set(i, task);
            }
        }
    }
}
