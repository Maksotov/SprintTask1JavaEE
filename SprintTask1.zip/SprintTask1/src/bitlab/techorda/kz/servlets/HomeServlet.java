package bitlab.techorda.kz.servlets;

import bitlab.techorda.kz.db.DBManager;
import bitlab.techorda.kz.db.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(value = "/home.html")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        List<Task> tasks = DBManager.getAllTasks();
        request.setAttribute("tasks", tasks);
        request.getRequestDispatcher("main.jsp").forward(request, response);
    }
}
