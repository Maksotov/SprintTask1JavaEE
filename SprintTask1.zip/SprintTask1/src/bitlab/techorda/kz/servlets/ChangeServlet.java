package bitlab.techorda.kz.servlets;

import bitlab.techorda.kz.db.DBManager;
import bitlab.techorda.kz.db.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@WebServlet(value = "/edel")
public class ChangeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        Long id = Long.parseLong(request.getParameter("task_id"));
        String name = request.getParameter("task_name");
        String description = request.getParameter("task_description");
        LocalDate src = LocalDate.parse(request.getParameter("task_date"), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dst = src.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
        String done = request.getParameter("done");
        String type = request.getParameter("btn");

        if(type.equals("edit")) {
            Task task = new Task(id, name, description, dst);
            boolean b = false;
            if(done.equals("Да")) {
                b = true;
            }
            task.setDone(b);
            DBManager.updateTask(task);
        }else {
            DBManager.deleteTask(id);
        }

        response.sendRedirect("/");
    }
}
