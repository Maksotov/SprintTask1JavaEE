package bitlab.techorda.kz.servlets;

import bitlab.techorda.kz.db.DBManager;
import bitlab.techorda.kz.db.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(value = "/details")
public class DetailsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        Long id = (long) -1;
        try {
            id = Long.parseLong(request.getParameter("task_id"));
        }catch (Exception e) {
        }
        Task task = DBManager.getTask(id);
        request.setAttribute("task", task);
        request.getRequestDispatcher("details.jsp").forward(request, response);
    }
}
